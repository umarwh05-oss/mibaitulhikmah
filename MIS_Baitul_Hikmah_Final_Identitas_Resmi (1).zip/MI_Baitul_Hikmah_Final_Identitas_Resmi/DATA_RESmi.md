# Data resmi yang dipakai

Sumber: Referensi Data Kemendikdasmen, NPSN 69756220.

- Nama: MIS BAITUL HIKMAH
- NPSN: 69756220
- Alamat: JL. 05 Desa Perintis Makmur
- Desa/Kelurahan: RIMBO MULYO
- Kecamatan: KEC. RIMBO BUJANG
- Kabupaten: KAB. TEBO
- Provinsi: PROV. JAMBI
- Status: SWASTA
- Bentuk Pendidikan: MI
- Kementerian Pembina: Kementerian Agama
- SK Pendirian: 011.1/384/2010
- Tanggal: 23-10-2010
- SK Operasional: Kd.05.09./3/PP.00.4/21/2011
- Tanggal: 25-01-2011
- Akreditasi: C
- Koordinat: -1.537334, 102.371547

Kontak (telepon, email, website) belum tersedia pada sumber tersebut.
