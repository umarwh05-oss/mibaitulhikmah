# MIS Baitul Hikmah — Starter Siap Deploy

## Stack
Next.js + Supabase Auth + Supabase PostgreSQL + Supabase Storage.

## Setup lokal
1. Install Node.js LTS.
2. `npm install`
3. Salin `.env.example` menjadi `.env.local`.
4. Isi URL, Publishable Key, dan Service Role Key dari project Supabase.
5. Jalankan `supabase/schema.sql` di SQL Editor Supabase.
6. Buat satu user admin di Supabase Authentication > Users.
7. Jalankan `npm run dev`.

## Deployment
Deploy repository ini ke Vercel, lalu masukkan environment variables yang sama di Project Settings > Environment Variables.
Set `NEXT_PUBLIC_SITE_URL` ke domain sekolah.

## Sebelum digunakan resmi
- Ganti data contoh dengan data resmi madrasah.
- Buat akun admin khusus sekolah.
- Jangan pernah memasukkan SERVICE_ROLE_KEY ke kode frontend.
- Pastikan bucket dokumen tetap PRIVATE.
- Tambahkan kebijakan RLS/role admin yang sesuai sebelum membuka fungsi edit/hapus.
- Uji upload, backup, dan pemulihan database.
- Lengkapi NPSN/NSM, alamat lengkap, kepala madrasah, kontak, logo, persyaratan dan jadwal PPDB.
